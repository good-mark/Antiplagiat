PAN'14 Training Corpus for Source Retrieval
===========================================

Corpus description
------------------

The corpus consists of HTML documents that contain plagiarism and annotations
as to the wherabouts within them. The annotations can be seen as background
colors in the the HTML files, the JSON files contain meta information amenable
for automated processing.


Your task: Plagiarism Source Retrieval
--------------------------------------

Your task is to use either the ChatNoir search engine, the Indri search engine,
or use your own ClueWeb09 search engine to retrieve all plagiarized sources for
a given suspicious document.


Access to the search engines
----------------------------

The ChatNoir search engine's API as well as Indri's API are accessible via
http://webis15.medien.uni-weimar.de/pan/

If you have problems accessing the search engines, please contact pan@webis.de.
